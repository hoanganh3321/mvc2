/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myCart;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author VICTUS HELLO
 */
public class CartObj implements Serializable {

    private Map<String, Integer> items;

    public Map<String, Integer> getItems() {
        return items;
    }

    public boolean addItemsToCart(String sku) {
        boolean result = false;
        //1.check existed id
        if (sku == null) {
            return result;
        }
        //id is valid
        if (!sku.trim().isEmpty()) {
            return result;
        }
        //2.check existed items
        if (this.items == null) {
            this.items = new HashMap<>();
        }
        //3.check existed items ->existed-->increase quantity, otherwise, drop item
        int quantity = 1;
        if (this.items.containsKey(sku)) {
            quantity = this.items.get(sku) + 1;
        }//items has existed in items
        //4.update items
        this.items.put(sku, quantity);
        result = true;
        return result;
    }

    public boolean removeItemFromCart(String sku) {
        boolean result = false;
        //1.check existed items
        if (this.items != null) {
            //2.check existed item -> existed -->remove otherwise do nothing
            if (this.items.containsKey(sku)) {
                this.items.remove(sku);
                //share nen xet items = null neu trong gio ko co gi 
                if (this.items.isEmpty()) {
                    this.items = null;
                }
                result = true;
            }
        }//end items has existed
        return result;
    }
}
