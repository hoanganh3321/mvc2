/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package registration;

import java.io.Serializable;

/**
 *
 * @author VICTUS HELLO
 */
public class RegistrationCart implements Serializable{
    protected String sku;
    protected String name;
    protected String description;//mapping lastname field
    protected float unitprice;//mapping isAdmin field
    protected int quantity;
    protected boolean status;

    public RegistrationCart() {
    }

    public RegistrationCart(String sku, String name, String description, float unitprice, boolean status) {
        this.sku = sku;
        this.name = name;
        this.description = description;
        this.unitprice = unitprice;
        this.status = status;
    }

    public RegistrationCart(String sku, String name, String description, float unitprice, int quantity, boolean status) {
        this.sku = sku;
        this.name = name;
        this.description = description;
        this.unitprice = unitprice;
        this.quantity = quantity;
        this.status = status;
    }

    public String getSku() {
        return sku;
    }

    public void setSku(String sku) {
        this.sku = sku;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public float getUnitprice() {
        return unitprice;
    }

    public void setUnitprice(float unitprice) {
        this.unitprice = unitprice;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "RegistrationCart{" + "sku=" + sku + ", name=" + name + ", description=" + description + ", unitprice=" + unitprice + ", quantity=" + quantity + ", status=" + status + '}';
    }
    
}
