/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package registration;

import db.util.DBHelper;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.naming.NamingException;

/**
 *
 * @author VICTUS HELLO
 */
public class RegistrationDAO implements Serializable {

    private List<RegistrationDTO> accounts;
    private List<RegistrationCart> accountsPro;

    public List<RegistrationDTO> getAccounts() {
        return accounts;
    }

    public List<RegistrationCart> getAccountsPro() {
        return accountsPro;
    }

    public void searchLastName(String searchValue) throws ClassNotFoundException, SQLException, NamingException {
        Connection con = null;
        PreparedStatement stm = null;
        ResultSet rs = null;
        boolean result = false;
        try {
            //1.get connection
            con = DBHelper.getConn();
            if (con != null) {
                //2.create SQL string
                String sql = "SELECT lastname, username, password, isAdmin FROM Registration WHERE lastname LIKE ?";
                //3.create stmt obj
                stm = con.prepareStatement(sql);
                stm.setString(1, "%" + searchValue + "%");
                //4.execute query
                rs = stm.executeQuery();
                //5.process result
                while (rs.next()) {
                    //5.1 mapping dto get data from rs
                    String username = rs.getString("username");
                    String password = rs.getString("password");
                    String lastname = rs.getString("lastname");
                    boolean role = rs.getBoolean("isAdmin");
                    //5.2 set data to dto properties
                    RegistrationDTO dto = new RegistrationDTO(username, password, username, role);
                    if (this.accounts == null) {
                        this.accounts = new ArrayList<>();
                    }//end accounts have not existed
                    this.accounts.add(dto);
                }//end account has existed
            }// end connection has been avaiable

        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stm != null) {
                stm.close();
            }
            if (con != null) {
                con.close();
            }
        }
    }

    public void addProduct() throws ClassNotFoundException, SQLException, NamingException {
        Connection con = null;
        PreparedStatement stm = null;
        ResultSet rs = null;
        boolean result = false;
        try {
            //1.get connection
            con = DBHelper.getConn();
            if (con != null) {
                //2.create SQL string
                String sql = "SELECT sku, name, description, unitprice, status FROM Product";
                //3.create stmt obj
                stm = con.prepareStatement(sql);
                //4.execute query
                rs = stm.executeQuery();
                //5.process result
                while (rs.next()) {
                    //5.1 mapping cart get data from rs
                    String sku = rs.getString("sku");
                    String name = rs.getString("name");
                    String description = rs.getString("description");
                    float unitprice = rs.getFloat("unitprice");
                    boolean status = rs.getBoolean("status");
                    //5.2 set data to dto properties
                    registration.RegistrationCart cart = new RegistrationCart(sku, name, description, unitprice, status);
                    if (this.accountsPro == null) {
                        this.accountsPro = new ArrayList<>();
                    }//end accounts have not existed
                    this.accountsPro.add(cart);
                }//end account has existed
            }// end connection has been avaiable

        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stm != null) {
                stm.close();
            }
            if (con != null) {
                con.close();
            }
        }
    }

    public boolean checkLogin(String username, String password) throws SQLException, ClassNotFoundException, NamingException {

        Connection con = null;
        PreparedStatement stm = null;
        ResultSet rs = null;
        boolean result = false;
        try {
            //1.get connection
            con = DBHelper.getConn();
            if (con != null) {
                //2.create SQL string
                String sql = "Select lastname From Registration  Where username=? and password=?";
                //3.create stmt obj
                stm = con.prepareStatement(sql);
                stm.setString(1, username);
                stm.setString(2, password);
                //4.execute query
                rs = stm.executeQuery();
                //5.process result
                if (rs.next()) {
                    result = true;
                }// username and password is authenticated
            }//end con has been av

        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stm != null) {
                stm.close();
            }
            if (con != null) {
                con.close();
            }
        }
        return result;
    }

    public boolean deleteAccount(String username) throws SQLException, NamingException, ClassNotFoundException {
        Connection con = null;
        PreparedStatement stm = null;
        boolean result = false;
        try {
            //1.get connection
            con = DBHelper.getConn();
            if (con != null) {
                //2.create SQL string
                String sql = "Delete From Registration Where username=?";
                //3.create stmt obj
                stm = con.prepareStatement(sql);
                stm.setString(1, username);
                //4.execute query
                int effectRows = stm.executeUpdate();
                //5.process result
                if (effectRows > 0) {
                    result = true;
                }
            }
        } finally {

            if (stm != null) {
                stm.close();
            }
            if (con != null) {
                con.close();
            }
        }
        return result;
    }

    public boolean update(String username, String password, boolean role) throws SQLException, NamingException, ClassNotFoundException {
        Connection con = null;
        PreparedStatement stm = null;
        try {
            //1.get connection
            con = DBHelper.getConn();
            if (con != null) {
                //2.create SQL string
                String sql = "Update Registration Set password=?,isAdmin=? Where username =?";
                //3.create stmt obj
                stm = con.prepareStatement(sql);
                stm.setString(1, password);
                stm.setBoolean(2, role);
                stm.setString(3, username);
                //4.execute query
                int effectRows = stm.executeUpdate();
                //5.process result
                if (effectRows > 0) {
                    return true;
                }
            }
        } finally {

            if (stm != null) {
                stm.close();
            }
            if (con != null) {
                con.close();
            }
        }
        return false;
    }
}
